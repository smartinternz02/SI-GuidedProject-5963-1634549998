# MalariaDetection-DL
https://www.kaggle.com/iarunava/cell-images-for-detecting-malaria
